package com.cts.medicalrepresentativeschedule.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.medicalrepresentativeschedule.Repo.MedicalRepresentativeRepository;
import com.cts.medicalrepresentativeschedule.model.RepSchedule;

@Service
public class MedicalRepresentativeScheduleServiceImpl implements MedicalRepresentativeScheduleService {
    
	@Override
	public List<RepSchedule> getRepSchedule(String scheduleDate) {
		
		// hard-coded value
		Date date = java.sql.Date.valueOf(scheduleDate);
		RepSchedule s1 = new RepSchedule("john", "dr.ishan", "1 to 2 pm", date, "123456789");
		
		List<RepSchedule> dummyList = new ArrayList<>();
		dummyList.add(s1);
		
		return dummyList;
	}


}
