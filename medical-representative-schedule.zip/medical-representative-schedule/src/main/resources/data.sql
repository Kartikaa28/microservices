insert into medical_representatives (rep_id,rep_name,rep_phone_number) values(1,'R1', '9456481521');
insert into medical_representatives (rep_id,rep_name,rep_phone_number) values(2,'R2', '7466481521');
insert into medical_representatives (rep_id,rep_name,rep_phone_number) values(3,'R3', '9846874134');